import { FastifyInstance, FastifyRequest, FastifyReply, RouteGenericInterface } from 'fastify';
import { z } from 'zod';
import { ZMQTranslationClient } from '../services/zmq-translation-client';
import { PrismaClient } from '../../libs/prisma/client';
import { randomUUID } from 'crypto';

// Schémas de validation
const ForceTranslationSchema = z.object({
  targetLanguage: z.string().min(2).max(5),
  model: z.enum(['basic', 'medium', 'premium']).optional()
});

const MessageParamsSchema = z.object({
  messageId: z.string().uuid()
});

const TargetLanguageParamsSchema = z.object({
  messageId: z.string().uuid(),
  targetLanguage: z.string().min(2).max(5)
});

// Interfaces pour Fastify routes
interface ForceTranslationRoute extends RouteGenericInterface {
  Body: {
    targetLanguage: string;
    model?: 'basic' | 'medium' | 'premium';
  };
  Params: {
    messageId: string;
  };
}

interface TranslationStatusRoute extends RouteGenericInterface {
  Params: {
    messageId: string;
    targetLanguage: string;
  };
}

interface MessageTranslationsRoute extends RouteGenericInterface {
  Params: {
    messageId: string;
  };
}

// Instance globale du client ZMQ
let zmqClient: ZMQTranslationClient | null = null;

// Initialiser le client ZMQ
async function getZMQClient(): Promise<ZMQTranslationClient> {
  if (!zmqClient) {
    const port = parseInt(process.env.ZMQ_PORT || '5555');
    const host = process.env.ZMQ_HOST || 'localhost';
    
    zmqClient = new ZMQTranslationClient(port, host);
    await zmqClient.initialize();
  }
  return zmqClient;
}

// Fonction pour traiter la traduction en arrière-plan
async function processTranslationAsync(
  messageId: string,
  text: string,
  sourceLanguage: string,
  targetLanguage: string,
  model: string,
  conversationId: string
): Promise<void> {
  const prisma = new PrismaClient();
  
  try {
    const client = await getZMQClient();
    
    const translationRequest = {
      messageId: messageId,
      text: text,
      sourceLanguage: sourceLanguage,
      targetLanguage: targetLanguage,
      modelType: model
    };

    // ZMQ est synchrone - la réponse arrive immédiatement
    const translationResponse = await client.translateText(translationRequest);
    
    if (translationResponse.status === 1) {
      // Succès - mettre à jour la traduction avec le résultat
      await prisma.messageTranslation.update({
        where: {
          messageId_targetLanguage: {
            messageId: messageId,
            targetLanguage: targetLanguage
          }
        },
        data: {
          translatedContent: translationResponse.translatedText,
          status: 'completed',
          confidenceScore: translationResponse.metadata?.confidenceScore || 0.9,
          cacheKey: `cache_${messageId}_${targetLanguage}`,
          updatedAt: new Date()
        }
      });

      // TODO: Diffuser via WebSocket à tous les clients connectés à cette conversation
      // que la traduction est prête
      console.log(`Traduction complétée pour message ${messageId} vers ${targetLanguage}`);
      
    } else {
      // Échec de la traduction
      await prisma.messageTranslation.update({
        where: {
          messageId_targetLanguage: {
            messageId: messageId,
            targetLanguage: targetLanguage
          }
        },
        data: {
          status: 'failed',
          updatedAt: new Date()
        }
      });

      console.error(`Échec de traduction pour message ${messageId} vers ${targetLanguage}`);
    }

  } catch (error) {
    console.error('Erreur lors de la traduction asynchrone:', error);
    
    // Mettre à jour le statut d'erreur
    await prisma.messageTranslation.update({
      where: {
        messageId_targetLanguage: {
          messageId: messageId,
          targetLanguage: targetLanguage
        }
      },
      data: {
        status: 'failed',
        updatedAt: new Date()
      }
    }).catch(console.error);
  } finally {
    await prisma.$disconnect();
  }
}

export async function messageRoutes(fastify: FastifyInstance): Promise<void> {
  const prisma = new PrismaClient();

  // Route pour forcer une traduction d'un message
  fastify.post<ForceTranslationRoute>(
    '/api/messages/:messageId/translate',
    {
      preHandler: fastify.authenticate,
      schema: {
        body: ForceTranslationSchema,
        params: MessageParamsSchema
      }
    },
    async (request, reply: FastifyReply) => {
      const { messageId } = request.params;
      const { targetLanguage, model = 'basic' } = request.body;
      const userId = request.user?.userId;

      if (!userId) {
        return reply.status(401).send({
          success: false,
          error: 'Non autorisé'
        });
      }

      try {
        // Vérifier que le message existe
        const message = await prisma.message.findUnique({
          where: { id: messageId },
          include: {
            conversation: {
              include: {
                members: true
              }
            },
            translations: {
              where: {
                targetLanguage: targetLanguage
              }
            }
          }
        });

        if (!message) {
          return reply.status(404).send({
            success: false,
            error: 'Message non trouvé'
          });
        }

        // Vérifier que l'utilisateur a accès à cette conversation
        const hasAccess = message.conversation.members.some(member => member.userId === userId);
        if (!hasAccess) {
          return reply.status(403).send({
            success: false,
            error: 'Accès non autorisé à cette conversation'
          });
        }

        // Vérifier si une traduction existe déjà pour cette langue
        const existingTranslation = message.translations[0];
        if (existingTranslation && existingTranslation.status === 'completed') {
          return reply.status(200).send({
            success: true,
            messageId: messageId,
            targetLanguage: targetLanguage,
            status: 'completed',
            translationId: existingTranslation.id,
            message: 'Traduction déjà disponible'
          });
        }

        // Créer ou mettre à jour l'enregistrement de traduction
        const translationId = randomUUID();
        
        await prisma.messageTranslation.upsert({
          where: {
            messageId_targetLanguage: {
              messageId: messageId,
              targetLanguage: targetLanguage
            }
          },
          update: {
            status: 'processing',
            translationModel: model,
            updatedAt: new Date()
          },
          create: {
            id: translationId,
            messageId: messageId,
            sourceLanguage: message.originalLanguage,
            targetLanguage: targetLanguage,
            translatedContent: '', // Sera rempli par le service de traduction
            translationModel: model,
            cacheKey: `${messageId}_${targetLanguage}_${Date.now()}`,
            status: 'processing',
            createdAt: new Date(),
            updatedAt: new Date()
          }
        });

        // Répondre immédiatement que la traduction est en cours
        reply.status(200).send({
          success: true,
          messageId: messageId,
          targetLanguage: targetLanguage,
          status: 'processing',
          translationId: translationId,
          estimatedTime: 5000 // 5 secondes
        });

        // Lancer la traduction en arrière-plan (fire and forget)
        processTranslationAsync(messageId, message.content, message.originalLanguage, targetLanguage, model, message.conversationId)
          .catch((error) => {
            console.error('Erreur lors de la traduction asynchrone:', error);
          });

      } catch (error) {
        console.error('Erreur lors de la demande de traduction:', error);
        return reply.status(500).send({
          success: false,
          error: 'Erreur interne du serveur'
        });
      }
    }
  );

  // Route pour vérifier le statut d'une traduction
  fastify.get<TranslationStatusRoute>(
    '/api/messages/:messageId/translate/:targetLanguage/status',
    {
      preHandler: fastify.authenticate,
      schema: {
        params: TargetLanguageParamsSchema
      }
    },
    async (request, reply: FastifyReply) => {
      const { messageId, targetLanguage } = request.params;
      const userId = request.user?.userId;

      if (!userId) {
        return reply.status(401).send({
          success: false,
          error: 'Non autorisé'
        });
      }

      try {
        // Vérifier que le message existe et que l'utilisateur y a accès
        const message = await prisma.message.findUnique({
          where: { id: messageId },
          include: {
            conversation: {
              include: {
                members: true
              }
            },
            translations: {
              where: {
                targetLanguage: targetLanguage
              }
            }
          }
        });

        if (!message) {
          return reply.status(404).send({
            success: false,
            error: 'Message non trouvé'
          });
        }

        const hasAccess = message.conversation.members.some(member => member.userId === userId);
        if (!hasAccess) {
          return reply.status(403).send({
            success: false,
            error: 'Accès non autorisé'
          });
        }

        const translation = message.translations[0];
        if (!translation) {
          return reply.status(404).send({
            success: false,
            error: 'Aucune traduction trouvée'
          });
        }

        return reply.status(200).send({
          success: true,
          messageId: messageId,
          targetLanguage: targetLanguage,
          status: translation.status,
          progress: translation.status === 'processing' ? 50 : (translation.status === 'completed' ? 100 : 0),
          translatedContent: translation.status === 'completed' ? translation.translatedContent : undefined,
          error: translation.status === 'failed' ? 'Erreur lors de la traduction' : undefined
        });

      } catch (error) {
        console.error('Erreur lors de la vérification du statut:', error);
        return reply.status(500).send({
          success: false,
          error: 'Erreur interne du serveur'
        });
      }
    }
  );

  // Route pour annuler une traduction en cours
  fastify.delete<TranslationStatusRoute>(
    '/api/messages/:messageId/translate/:targetLanguage',
    {
      preHandler: fastify.authenticate,
      schema: {
        params: TargetLanguageParamsSchema
      }
    },
    async (request, reply: FastifyReply) => {
      const { messageId, targetLanguage } = request.params;
      const userId = request.user?.userId;

      if (!userId) {
        return reply.status(401).send({
          success: false,
          error: 'Non autorisé'
        });
      }

      try {
        // Vérifier l'accès et supprimer la traduction
        const message = await prisma.message.findUnique({
          where: { id: messageId },
          include: {
            conversation: {
              include: {
                members: true
              }
            }
          }
        });

        if (!message) {
          return reply.status(404).send({
            success: false,
            error: 'Message non trouvé'
          });
        }

        const hasAccess = message.conversation.members.some(member => member.userId === userId);
        if (!hasAccess) {
          return reply.status(403).send({
            success: false,
            error: 'Accès non autorisé'
          });
        }

        await prisma.messageTranslation.delete({
          where: {
            messageId_targetLanguage: {
              messageId: messageId,
              targetLanguage: targetLanguage
            }
          }
        });

        return reply.status(200).send({
          success: true,
          message: 'Traduction annulée'
        });

      } catch (error) {
        console.error('Erreur lors de l\'annulation:', error);
        return reply.status(500).send({
          success: false,
          error: 'Erreur interne du serveur'
        });
      }
    }
  );

  // Route pour obtenir toutes les traductions d'un message
  fastify.get<MessageTranslationsRoute>(
    '/api/messages/:messageId/translations',
    {
      preHandler: fastify.authenticate,
      schema: {
        params: MessageParamsSchema
      }
    },
    async (request, reply: FastifyReply) => {
      const { messageId } = request.params;
      const userId = request.user?.userId;

      if (!userId) {
        return reply.status(401).send({
          success: false,
          error: 'Non autorisé'
        });
      }

      try {
        const message = await prisma.message.findUnique({
          where: { id: messageId },
          include: {
            conversation: {
              include: {
                members: true
              }
            },
            translations: true
          }
        });

        if (!message) {
          return reply.status(404).send({
            success: false,
            error: 'Message non trouvé'
          });
        }

        const hasAccess = message.conversation.members.some(member => member.userId === userId);
        if (!hasAccess) {
          return reply.status(403).send({
            success: false,
            error: 'Accès non autorisé'
          });
        }

        const translations = message.translations.map(t => ({
          messageId: t.messageId,
          targetLanguage: t.targetLanguage,
          status: t.status,
          translatedContent: t.status === 'completed' ? t.translatedContent : undefined,
          translationModel: t.translationModel,
          confidence: t.confidenceScore,
          createdAt: t.createdAt,
          updatedAt: t.updatedAt
        }));

        return reply.status(200).send({
          success: true,
          translations: translations
        });

      } catch (error) {
        console.error('Erreur lors de la récupération des traductions:', error);
        return reply.status(500).send({
          success: false,
          error: 'Erreur interne du serveur'
        });
      }
    }
  );
}
