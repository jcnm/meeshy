/**
 * Service singleton ZMQ pour communication avec le Translator
 * Évite la duplication de configuration ZMQ dans tous les services
 */

import { ZMQTranslationClient } from './zmq-translation-client';

export class ZMQTranslationService {
  private static instance: ZMQTranslationService;
  private client: ZMQTranslationClient | null = null;
  private isInitialized = false;

  private constructor() {}

  /**
   * Récupère l'instance singleton du service ZMQ
   */
  public static getInstance(): ZMQTranslationService {
    if (!ZMQTranslationService.instance) {
      ZMQTranslationService.instance = new ZMQTranslationService();
    }
    return ZMQTranslationService.instance;
  }

  /**
   * Initialise le client ZMQ avec la configuration
   */
  public async initialize(): Promise<void> {
    if (this.isInitialized) {
      console.log('🔄 Service ZMQ déjà initialisé');
      return;
    }

    try {
      const port = parseInt(process.env.ZMQ_PORT || process.env.TRANSLATOR_ZMQ_PORT || '5555');
      const host = process.env.ZMQ_HOST || process.env.TRANSLATOR_HOST || 'localhost';
      
      console.log(`🔌 Initialisation service ZMQ singleton sur ${host}:${port}`);
      
      this.client = new ZMQTranslationClient(port, host);
      await this.client.initialize();
      
      this.isInitialized = true;
      console.log('✅ Service ZMQ singleton initialisé avec succès');
      
    } catch (error) {
      console.error('❌ Erreur initialisation service ZMQ singleton:', error);
      throw error;
    }
  }

  /**
   * Récupère le client ZMQ initialisé
   */
  public async getClient(): Promise<ZMQTranslationClient> {
    if (!this.isInitialized || !this.client) {
      await this.initialize();
    }
    
    if (!this.client) {
      throw new Error('Client ZMQ non disponible');
    }
    
    return this.client;
  }

  /**
   * Vérifie si le service est prêt
   */
  public isReady(): boolean {
    return this.isInitialized && this.client !== null;
  }

  /**
   * Effectue un health check via ZMQ
   */
  public async healthCheck(): Promise<boolean> {
    try {
      if (!this.isReady()) {
        return false;
      }
      
      const client = await this.getClient();
      return await client.healthCheck();
      
    } catch (error) {
      console.error('❌ Health check ZMQ échoué:', error);
      return false;
    }
  }

  /**
   * Traduit un texte via ZMQ
   */
  public async translateText(request: {
    messageId: string;
    text: string;
    sourceLanguage: string;
    targetLanguage: string;
    modelType?: string;
    conversationId?: string;
  }): Promise<{
    messageId: string;
    translatedText: string;
    detectedSourceLanguage: string;
    status: number;
    metadata?: {
      confidenceScore: number;
      fromCache: boolean;
      modelUsed: string;
    };
  }> {
    const client = await this.getClient();
    return await client.translateText(request);
  }

  /**
   * Ferme le service ZMQ
   */
  public async close(): Promise<void> {
    if (this.client) {
      await this.client.close();
      this.client = null;
    }
    this.isInitialized = false;
    console.log('✅ Service ZMQ singleton fermé');
  }
}

// Export de l'instance singleton
export const zmqTranslationService = ZMQTranslationService.getInstance();
