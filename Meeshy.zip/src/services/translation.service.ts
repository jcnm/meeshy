/**
 * Service de traduction unifié pour Meeshy
 * Utilise la nouvelle API Transformers.js avec AutoTokenizer et AutoModelForSeq2SeqLM
 * pour une meilleure robustesse et performance avec les modèles Xenova ONNX
 */
/**
 * Service de traduction unifié pour Meeshy
 * Utilise l'API pipeline de Hugging Face Transformers.js
 */
import { pipeline, Pipeline } from '@huggingface/transformers';
import { 
  selectModelForMessage,
  getActiveModelConfig,
  ACTIVE_MODELS,
  type AllowedModelType,
  type UnifiedModelConfig 
} from '@/lib/unified-model-config';
import { convertToNLLBCode } from '@/utils/nllb-language-mapping';
import { cleanTranslationOutput } from '@/utils/translation-cleaner';

// === TYPES ===

export interface TranslationResult {
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
  modelUsed: string;
  confidence: number;
  fromCache: boolean;
}

export interface TranslationOptions {
  preferredModel?: AllowedModelType;
  forceRefresh?: boolean;
  onProgress?: (progress: TranslationProgress) => void;
}

export interface TranslationProgress {
  modelName: string;
  status: 'downloading' | 'loading' | 'ready' | 'error';
  progress?: number;
  error?: string;
}

export interface LanguageDetectionResult {
  language: string;
  confidence: number;
  detectedLanguages: Array<{language: string; confidence: number}>;
}

// === INTERFACES INTERNES ===

interface ModelPipeline {
  pipeline: Pipeline;
  config: UnifiedModelConfig;
}

interface CachedTranslation {
  original: string;
  translated: string;
  sourceLanguage: string;
  targetLanguage: string;
  timestamp: number;
  modelUsed: string;
}

/**
 * Service de traduction utilisant l'API pipeline
 */
export class TranslationService {
  private static instance: TranslationService;
  private loadedPipelines = new Map<AllowedModelType, ModelPipeline>();
  private loadingPromises = new Map<AllowedModelType, Promise<ModelPipeline>>();
  private cache = new Map<string, CachedTranslation>();
  private languageDetector: Pipeline | null = null;
  
  // Configuration
  private readonly CACHE_EXPIRY = 7 * 24 * 60 * 60 * 1000; // 7 jours
  private readonly MAX_CACHE_SIZE = 1000;
  private readonly STORAGE_KEY_CACHE = 'meeshy_translation_cache';

  static getInstance(): TranslationService {
    if (!TranslationService.instance) {
      TranslationService.instance = new TranslationService();
    }
    return TranslationService.instance;
  }

  private constructor() {
    this.loadCacheFromStorage();
  }

  // === API PUBLIQUE ===

  /**
   * Traduction principale avec détection automatique de langue
   */
  async translate(
    text: string,
    targetLanguage: string,
    sourceLanguage: string = 'auto',
    options: TranslationOptions = {}
  ): Promise<TranslationResult> {
    // Détection automatique de langue si nécessaire
    const actualSourceLanguage = sourceLanguage;

    // Vérifier le cache
    if (!options.forceRefresh) {
      const cached = this.getFromCache(text, actualSourceLanguage, targetLanguage);
      if (cached) {
        return {
          translatedText: cached.translated,
          sourceLanguage: actualSourceLanguage,
          targetLanguage,
          modelUsed: cached.modelUsed,
          confidence: 1.0,
          fromCache: true
        };
      }
    }

    // Sélectionner et charger le modèle
    const modelType = options.preferredModel || this.selectOptimalModel(text);
    const modelPipeline = await this.loadTranslationPipeline(modelType, options.onProgress);

    // Effectuer la traduction
    const result = await this.performTranslation(
      modelPipeline, 
      text, 
      actualSourceLanguage, 
      targetLanguage
    );

    // Mettre en cache
    this.addToCache(text, result.translatedText, actualSourceLanguage, targetLanguage, result.modelUsed);

    return {
      ...result,
      sourceLanguage: actualSourceLanguage,
      fromCache: false
    };
  }

  /**
   * Charge un pipeline de traduction
   */
  async loadTranslationPipeline(
    modelType: AllowedModelType, 
    onProgress?: (progress: TranslationProgress) => void
  ): Promise<ModelPipeline> {
    // Si déjà chargé
    if (this.loadedPipelines.has(modelType)) {
      return this.loadedPipelines.get(modelType)!;
    }

    // Si en cours de chargement
    if (this.loadingPromises.has(modelType)) {
      return this.loadingPromises.get(modelType)!;
    }

    const config = getActiveModelConfig('high');
    const loadingPromise = this.doLoadPipeline(modelType, config, onProgress);
    this.loadingPromises.set(modelType, loadingPromise);

    try {
      const modelPipeline = await loadingPromise;
      this.loadedPipelines.set(modelType, modelPipeline);
      this.loadingPromises.delete(modelType);
      return modelPipeline;
    } catch (error) {
      this.loadingPromises.delete(modelType);
      throw error;
    }
  }

  /**
   * Décharge un pipeline
   */
  unloadPipeline(modelType: AllowedModelType): boolean {
    return this.loadedPipelines.delete(modelType);
  }

  /**
   * Décharge tous les pipelines
   */
  unloadAllPipelines(): void {
    this.loadedPipelines.clear();
    this.loadingPromises.clear();
    this.languageDetector = null;
  }

  /**
   * Vide le cache
   */
  clearCache(): void {
    this.cache.clear();
    this.saveCacheToStorage();
  }

  /**
   * Statistiques du service
   */
  getStats() {
    return {
      loadedPipelines: Array.from(this.loadedPipelines.keys()),
      loadingPipelines: Array.from(this.loadingPromises.keys()),
      cacheSize: this.cache.size,
      hasLanguageDetector: !!this.languageDetector
    };
  }

  private selectOptimalModel(text: string): AllowedModelType {
    const selection = selectModelForMessage(text.length, text.length > 100 ? 'complex' : 'simple');
    return selection.type === 'basic' ? ACTIVE_MODELS.basicModel : ACTIVE_MODELS.highModel;
  }

  private async doLoadPipeline(
    modelType: AllowedModelType,
    config: UnifiedModelConfig,
    onProgress?: (progress: TranslationProgress) => void
  ): Promise<ModelPipeline> {
    try {
      onProgress?.({
        modelName: config.displayName,
        status: 'downloading',
        progress: 0
      });

      // Créer le pipeline de traduction
      const translationPipeline = await pipeline(
        'translation', 
        config.huggingFaceId,
        {
          progress_callback: (progressInfo: any) => {
            onProgress?.({
              modelName: config.displayName,
              status: 'downloading',
              progress: Math.round((progressInfo.progress || 0) * 100)
            });
          }
        }
      );

      onProgress?.({
        modelName: config.displayName,
        status: 'ready',
        progress: 100
      });

      return { 
        pipeline: translationPipeline, 
        config 
      };
    } catch (error) {
      onProgress?.({
        modelName: config.displayName,
        status: 'error',
        error: error instanceof Error ? error.message : 'Erreur inconnue'
      });
      throw error;
    }
  }

  private async performTranslation(
    modelPipeline: ModelPipeline,
    text: string,
    sourceLanguage: string,
    targetLanguage: string
  ): Promise<Omit<TranslationResult, 'sourceLanguage' | 'fromCache'>> {
    const { pipeline: translationPipeline, config } = modelPipeline;
    const isNLLBModel = config.family === 'NLLB';

    try {
      let result;

      if (isNLLBModel) {
        // Pour les modèles NLLB, utiliser les codes de langue spécifiques
        const srcLang = convertToNLLBCode(sourceLanguage);
        const tgtLang = convertToNLLBCode(targetLanguage);
        
        result = await translationPipeline(text, {
          src_lang: srcLang,
          tgt_lang: tgtLang,
        });
      } else {
        // Pour les autres modèles (MT5, etc.)
        result = await translationPipeline(text, {
          src_lang: sourceLanguage,
          tgt_lang: targetLanguage,
        });
      }

      // Extraire le texte traduit
      const translatedText = Array.isArray(result) 
        ? result[0]?.translation_text || result[0]?.generated_text || ''
        : result?.translation_text || result?.generated_text || '';

      if (!translatedText) {
        throw new Error('Aucune traduction générée par le modèle');
      }

      // Nettoyer la sortie
      const cleanedText = cleanTranslationOutput(translatedText).trim();

      return {
        translatedText: cleanedText,
        targetLanguage,
        modelUsed: config.name,
        confidence: 0.9
      };

    } catch (error) {
      console.error('Erreur lors de la traduction:', error);
      
      if (error instanceof Error) {
        const message = error.message;
        
        // Gérer les erreurs de langue non supportée
        if (message.includes('_Latn') || message.includes('_Cyrl') || message.includes('_Arab')) {
          throw new Error(`Langue non supportée par ${config.displayName}. Vérifiez les langues source (${sourceLanguage}) et cible (${targetLanguage}).`);
        }
        
        if (message.includes('non supportée par')) {
          throw error;
        }
      }
      
      throw new Error(`Échec de la traduction avec ${config.displayName}: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
    }
  }

  // === GESTION DU CACHE ===

  private generateCacheKey(text: string, sourceLanguage: string, targetLanguage: string): string {
    return `${text}|${sourceLanguage}|${targetLanguage}`;
  }

  private addToCache(
    text: string,
    translated: string,
    sourceLanguage: string,
    targetLanguage: string,
    modelUsed: string
  ): void {
    const cacheKey = this.generateCacheKey(text, sourceLanguage, targetLanguage);
    this.cache.set(cacheKey, {
      original: text,
      translated,
      sourceLanguage,
      targetLanguage,
      timestamp: Date.now(),
      modelUsed
    });
    
    this.cleanExpiredCache();
    this.saveCacheToStorage();
  }

  private getFromCache(
    text: string,
    sourceLanguage: string,
    targetLanguage: string
  ): CachedTranslation | null {
    const cacheKey = this.generateCacheKey(text, sourceLanguage, targetLanguage);
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.CACHE_EXPIRY) {
      return cached;
    }
    
    if (cached) {
      this.cache.delete(cacheKey);
    }
    
    return null;
  }

  private cleanExpiredCache(): void {
    const now = Date.now();
    
    // Supprimer les entrées expirées
    for (const [key, cached] of this.cache.entries()) {
      if (now - cached.timestamp > this.CACHE_EXPIRY) {
        this.cache.delete(key);
      }
    }
    
    // Limiter la taille du cache
    if (this.cache.size > this.MAX_CACHE_SIZE) {
      const entries = Array.from(this.cache.entries());
      entries.sort((a, b) => a[1].timestamp - b[1].timestamp);
      const toDelete = entries.slice(0, this.cache.size - this.MAX_CACHE_SIZE);
      toDelete.forEach(([key]) => this.cache.delete(key));
    }
  }

  private loadCacheFromStorage(): void {
    if (typeof window === 'undefined') return;
    
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY_CACHE);
      if (stored) {
        const parsed = JSON.parse(stored);
        this.cache = new Map(Object.entries(parsed));
        this.cleanExpiredCache();
      }
    } catch (error) {
      console.warn('Erreur lors du chargement du cache:', error);
    }
  }

  private saveCacheToStorage(): void {
    if (typeof window === 'undefined') return;
    
    try {
      const cacheObject = Object.fromEntries(this.cache);
      localStorage.setItem(this.STORAGE_KEY_CACHE, JSON.stringify(cacheObject));
    } catch (error) {
      console.warn('Erreur lors de la sauvegarde du cache:', error);
    }
  }
}

// Instance singleton
export const translationService = TranslationService.getInstance();
