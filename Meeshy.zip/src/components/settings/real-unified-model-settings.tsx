'use client';

import { RealModelDownloader } from '@/components/models/real-model-downloader';

/**
 * Paramètres des modèles - Version PRODUCTION avec vrais téléchargements
 */
export function UnifiedModelSettings() {
  return <RealModelDownloader />;
}
