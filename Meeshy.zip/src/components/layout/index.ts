// Composants de layout
export { Navigation } from './Navigation';
export { ResponsiveLayout, PageHeader, PageContent } from './ResponsiveLayout';
