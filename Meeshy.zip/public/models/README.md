# Modèles de Traduction

Ce répertoire contient les modèles TensorFlow.js pour la traduction automatique.

## Structure

- `mt5/` : Modèle MT5 pour les traductions courtes et simples
- `nllb/` : Modèle NLLB pour les traductions longues et complexes

## Installation des Modèles

Pour utiliser de vrais modèles TensorFlow.js, vous pouvez :

1. **Télécharger des modèles pré-convertis** depuis Hugging Face :
   ```bash
   # Exemple pour MT5
   wget https://huggingface.co/google/mt5-small/resolve/main/model.json -O public/models/mt5/model.json
   ```

2. **Convertir vos propres modèles** avec TensorFlow.js Converter :
   ```bash
   pip install tensorflowjs
   tensorflowjs_converter --input_format=tf_saved_model --output_format=tfjs_graph_model ./model/mt5 ./public/models/mt5/
   ```

3. **Utiliser des modèles web-optimisés** :
   - Modèles quantifiés pour de meilleures performances
   - Modèles shardés pour un chargement progressif

## Fallback

En l'absence de modèles locaux, l'application utilise :
1. L'API MyMemory (gratuite) pour les traductions réelles
2. Un système de simulation avec dictionnaire étendu
3. Un cache localStorage pour éviter les requêtes répétées

## Performance

- MT5 : Optimisé pour les messages ≤50 caractères
- NLLB : Conçu pour les textes longs et complexes
- Cache localStorage pour les traductions fréquentes
- Lazy loading des modèles selon les besoins
