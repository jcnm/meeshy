-- AlterTable
ALTER TABLE "users" ADD COLUMN "customDestinationLanguage" TEXT;
