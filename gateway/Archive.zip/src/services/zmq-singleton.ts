/**
 * ZMQSingleton.ts - Service singleton ZMQ simplifié
 */
import { EventEmitter } from 'events';
import * as zmq from 'zeromq';
import { randomUUID } from 'crypto';

export interface TranslationRequest {
  taskId?: string;
  messageId?: string;  // Pour retraduction
  conversationId?: string; // Pour nouveau message
  linkId?: string; // Pour message via lien
  text: string;
  sourceLanguage: string;
  targetLanguages: string[];
  modelType?: string;
  requestType: 'direct' | 'message' | 'retranslation';
}

export interface TranslationResult {
  taskId: string;
  messageId?: string;
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
  confidenceScore: number;
  modelType: string;
  fromCache: boolean;
  // Métadonnées techniques
  workerId?: string;
  translationTime?: number;
  queueTime?: number;
}

class ZMQSingleton extends EventEmitter {
  private static instance: ZMQSingleton | null = null;
  private static isInitializing = false;

  private pushSocket: zmq.Push | null = null;
  private subSocket: zmq.Subscriber | null = null;
  private isRunning = false;
  private pendingRequests = new Map<string, TranslationRequest>();

  private constructor() {
    super();
  }

  static async getInstance(): Promise<ZMQSingleton> {
    if (this.instance) {
      return this.instance;
    }

    if (this.isInitializing) {
      // Attendre l'initialisation en cours
      return new Promise((resolve, reject) => {
        const checkInstance = () => {
          if (this.instance) {
            resolve(this.instance);
          } else if (!this.isInitializing) {
            reject(new Error('Initialization failed'));
          } else {
            setTimeout(checkInstance, 50);
          }
        };
        checkInstance();
      });
    }

    this.isInitializing = true;
    
    try {
      this.instance = new ZMQSingleton();
      await this.instance.initialize();
      return this.instance;
    } finally {
      this.isInitializing = false;
    }
  }

  private async initialize(): Promise<void> {
    console.log('[ZMQ-Singleton] Initialisation...');
    
    // Socket PUSH pour envoyer les requêtes
    this.pushSocket = new zmq.Push();
    await this.pushSocket.connect(`tcp://${process.env.ZMQ_HOST || '127.0.0.1'}:${process.env.ZMQ_PUSH_PORT || '5555'}`);
    
    // Socket SUB pour recevoir les résultats
    this.subSocket = new zmq.Subscriber();
    await this.subSocket.connect(`tcp://${process.env.ZMQ_HOST || '127.0.0.1'}:${process.env.ZMQ_SUB_PORT || '5558'}`);
    await this.subSocket.subscribe(''); // S'abonner à tous les messages
    
    this.isRunning = true;
    this._startResultListener();
    
    console.log('[ZMQ-Singleton] ✅ Initialisé avec succès');
  }

  private async _startResultListener(): Promise<void> {
    if (!this.subSocket) return;

    try {
      for await (const [message] of this.subSocket) {
        if (!this.isRunning) break;
        
        try {
          const event = JSON.parse(message.toString());
          
          if (event.type === 'translation_completed') {
            this.emit('translationCompleted', {
              taskId: event.taskId,
              result: event.result,
              targetLanguage: event.targetLanguage
            });
          } else if (event.type === 'translation_error') {
            this.emit('translationError', {
              taskId: event.taskId,
              error: event.error,
              messageId: event.messageId
            });
          }
        } catch (parseError) {
          console.error('[ZMQ-Singleton] Erreur parsing message:', parseError);
        }
      }
    } catch (error) {
      if (this.isRunning) {
        console.error('[ZMQ-Singleton] Erreur écoute résultats:', error);
      }
    }
  }

  async sendTranslationRequest(request: TranslationRequest): Promise<string> {
    if (!this.pushSocket) {
      throw new Error('ZMQ non initialisé');
    }

    const taskId = request.taskId || randomUUID();
    
    const message = {
      taskId,
      ...request,
      timestamp: Date.now()
    };

    this.pendingRequests.set(taskId, request);
    
    await this.pushSocket.send(JSON.stringify(message));
    console.log(`[ZMQ-Singleton] Requête envoyée: ${taskId} (${request.requestType})`);
    
    return taskId;
  }

  async close(): Promise<void> {
    this.isRunning = false;
    
    if (this.pushSocket) {
      await this.pushSocket.close();
      this.pushSocket = null;
    }
    
    if (this.subSocket) {
      await this.subSocket.close();
      this.subSocket = null;
    }
    
    this.pendingRequests.clear();
    console.log('[ZMQ-Singleton] ✅ Fermé');
  }

  static async closeInstance(): Promise<void> {
    if (this.instance) {
      await this.instance.close();
      this.instance = null;
    }
  }
}

export { ZMQSingleton };